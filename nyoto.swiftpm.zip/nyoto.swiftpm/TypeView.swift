import SwiftUI

struct TypeView: View {
    var body: some View {
        NavigationStack{
            ZStack {
                Image("menu")
                    .imageScale(.medium)
                    .foregroundColor(.accentColor)
                VStack{
                    HStack{
                        NavigationLink(destination: ChoiceView(imageName: "soto-padang", itemName: textContent[0])) {
                            CardView(imageName: "soto-padang", itemName: textContent[0].sotoType)
                        }.padding(.trailing,10)
                        NavigationLink(destination: ChoiceView(imageName: "soto_banjar", itemName: textContent[1])) {
                            CardView(imageName: "soto_banjar", itemName: textContent[1].sotoType)
                        }.padding(.trailing,10)
                        NavigationLink(destination: ChoiceView(imageName: "soto-betawi", itemName: textContent[2])) {
                            CardView(imageName: "soto-betawi", itemName: textContent[2].sotoType)
                        }
                    }.padding(.bottom,30)
                    HStack{
                        NavigationLink(destination: ChoiceView(imageName: "soto_surabaya", itemName: textContent[3])) {
                            CardView(imageName: "soto_surabaya", itemName: textContent[3].sotoType)
                        }.padding(.trailing,10)
                        NavigationLink(destination: ChoiceView(imageName: "soto-madura", itemName: textContent[4])) {
                            CardView(imageName: "soto-madura", itemName: textContent[4].sotoType)
                        }.padding(.trailing,10)
                        NavigationLink(destination: ChoiceView(imageName: "coto_makassar", itemName: textContent[5])) {
                            CardView(imageName: "coto_makassar", itemName: textContent[5].sotoType)
                        }
                    }
                    HStack{
                        CartoonTextBubble(text: "Please choose our menu, actually there are more than 6 type of soto in Indonesia, but right now, these six are the only one that ready to be served.", textSize: 23).frame(width: 600)
                        Image("person")
                    }
                }.offset(y:40)
            }.navigationBarBackButtonHidden(true) // Hide the default back button
                .navigationBarItems(leading: MyCustomBackButton())
        }
    }
}

struct CardView: View {
    let imageName: String
    let itemName: String
    
    var body: some View {
        VStack {
            Image(imageName)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 250, height: 250)
                .cornerRadius(10)
                .padding(.init(top: -28, leading: 10, bottom: 0, trailing: 10))
            Text(itemName)
                .font(.system(size: 35,weight: .bold))
                .foregroundColor(.black)
                .padding(.init(top: -30, leading: 10, bottom: 20, trailing: 10))
        }
        .background(Color.white)
        .cornerRadius(10)
        .shadow(radius: 5)
    }
}
