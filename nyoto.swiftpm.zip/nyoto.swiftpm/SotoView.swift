import SwiftUI

struct SotoView: View {
    
    @State private var pageNo = 1
    var body: some View {
        NavigationStack{
            ZStack{
                VStack(alignment:.trailing){
                    Image("soto")
                        .imageScale(/*@START_MENU_TOKEN@*/.medium/*@END_MENU_TOKEN@*/)
                    Text("Image Source: https://www.pinterest.com/pin/115264071700592543/")
                }
                if (pageNo == 1){
                    HStack(alignment: .top){
                        Image("person")
                        VStack(alignment:.trailing){
                            CartoonTextBubble(text: "Soto is a traditional Indonesian soup known for its rich flavor and variety of ingredients. It typically consists of a clear broth flavored with aromatic herbs and spices such as lemongrass, ginger, garlic, and shallots. The soup is often made with chicken, beef, or offal, and commonly includes ingredients like rice noodles, hard-boiled eggs, bean sprouts, and fried shallots. Soto is usually served with a side of rice and garnished with lime wedges, chili sauce, and fresh herbs like cilantro or green onions. There are numerous regional variations of soto across Indonesia, each with its own unique twist on ingredients and flavors.", textSize: 20)
                            Button(action: {pageNo += 1}, label: {
                                Capsule()
                                    .fill(Color(red:168/255, green:0/255,blue:0/255))
                                    .frame(width: 80,height: 20)
                                    .overlay(Text("Next").foregroundColor(.white).font(.system(size: 12,weight: .bold)))
                                    .padding(.leading,40)
                            }).padding(.trailing,20)
                        }.frame(width:1300)
                    }.offset(y:350)
                } else if (pageNo == 2){
                    HStack(alignment: .top){
                        Image("person")
                        VStack(alignment:.trailing){
                            CartoonTextBubble(text: "The origins of soto trace back centuries in the culinary history of Indonesia. While the exact founder of soto remains uncertain, its emergence likely stems from the rich tapestry of Indonesian culture, blending indigenous ingredients with influences from Chinese, Indian, Arab, and European culinary traditions. Historically, soto served as a hearty and nourishing dish enjoyed by communities across the Indonesian archipelago. Its versatility allowed for regional adaptations, leading to the creation of various soto variations reflecting local ingredients and tastes. Over time, soto became not just a beloved comfort food but also an integral part of Indonesian identity and cultural heritage, symbolizing the country's diverse culinary landscape and the spirit of unity in diversity. Today, soto continues to be cherished by Indonesians and appreciated by food enthusiasts worldwide, showcasing the enduring legacy of this flavorful and comforting soup.", textSize: 20)
                            Button(action: {pageNo += 1}, label: {
                                Capsule()
                                    .fill(Color(red:168/255, green:0/255,blue:0/255))
                                    .frame(width: 80,height: 20)
                                    .overlay(Text("Next").foregroundColor(.white).font(.system(size: 12,weight: .bold)))
                                    .padding(.leading,40)
                            }).padding(.trailing,20)
                        }.frame(width:1300)
                    }.offset(y:350) 
                } else if (pageNo == 3) {
                    HStack(alignment: .top){
                        Image("person")
                        VStack(alignment:.trailing){
                            CartoonTextBubble(text: "Soto is widely available across Indonesia, reflecting its status as one of the nation's most beloved culinary treasures. From bustling street food stalls to upscale restaurants, soto can be found in virtually every corner of the archipelago, catering to diverse tastes and preferences. Each region of Indonesia boasts its own unique variation of soto, featuring local ingredients and culinary techniques that showcase the area's distinct flavors and cultural heritage. In urban centers like Jakarta, Bandung, and Surabaya, soto is readily available in traditional eateries known as warungs, as well as in modern dining establishments. In rural areas and smaller towns, families often prepare homemade soto recipes passed down through generations, adding a personal touch to this cherished dish. Additionally, soto is frequently served during special occasions, festivals, and religious celebrations, further cementing its significance for Indonesian", textSize: 20)
                            Button(action: {pageNo += 1}, label: {
                                Capsule()
                                    .fill(Color(red:168/255, green:0/255,blue:0/255))
                                    .frame(width: 80,height: 20)
                                    .overlay(Text("Next").foregroundColor(.white).font(.system(size: 12,weight: .bold)))
                                    .padding(.leading,40)
                            }).padding(.trailing,20)
                        }.frame(width:1300)
                    }.offset(y:350)
                } else if (pageNo == 4){
                    HStack(alignment: .top){
                        Image("person")
                        VStack(alignment:.trailing){
                            CartoonTextBubble(text: "Some interesting facts about soto. Its name derived from the Hokkien Chinese word 'sio thau' meaning meat soup, reflecting Chinese influence, it has become a breakfast staple in many parts of Indonesia, offering a comforting start to the day. Beyond its culinary delight, soto is also believed to possess healing properties, with its aromatic spices and herbs thought to alleviate cold and flu symptoms. Adding to its charm, some Indonesian cities host vibrant soto festivals, where diverse variations of the dish are celebrated, providing a delightful opportunity for the public to indulge in its flavorful diversity.", textSize: 20)
                            Button(action: {pageNo += 1}, label: {
                                Capsule()
                                    .fill(Color(red:168/255, green:0/255,blue:0/255))
                                    .frame(width: 80,height: 20)
                                    .overlay(Text("Next").foregroundColor(.white).font(.system(size: 12,weight: .bold)))
                                    .padding(.leading,40)
                            }).padding(.trailing,20)
                        }.frame(width:1300)
                    }.offset(y:350)
                } else {
                    HStack(alignment: .top){
                        Image("person")
                        VStack(alignment:.center){
                            CartoonTextBubble(text: "Now that you've learned about soto and its various details, let's delve into specific types of soto, discuss which might be considered the healthiest, examine their calorie content, and explore their recipes. If you're interested in discovering more about these aspects, simply click the proceed button.", textSize: 20)
                            NavigationLink(destination: TypeView()) {
                                Capsule()
                                    .fill(Color(red:168/255, green:0/255,blue:0/255))
                                    .frame(width: 150,height: 40)
                                    .overlay(Text("Proceed").foregroundColor(.white).font(.system(size: 20,weight: .bold)))
                                    .padding(.leading,40)
                            }
                        }.frame(width:1300)
                    }.offset(y:350)
                }
            }
            .navigationBarBackButtonHidden(true) // Hide the default back button
            .navigationBarItems(leading: MyCustomBackButton())
        }
    }
}


