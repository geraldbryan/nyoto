import SwiftUI

extension Color {
    static let maroon = Color(red: 128/255, green: 0/255, blue: 0/255)
}

struct ContentView: View {
    var body: some View {
        NavigationStack{
            ZStack {
                Image("landing_page")
                    .imageScale(.medium)
                    .foregroundColor(.accentColor)
                VStack{
                    CartoonTextBubble(text: "Hello, Welcome to Nyoto! I'm Tono and I will guide you about Soto, which is one of the most popular dish in Indonesia. There are different type of Soto and you can order it here. So, before deciding what to order, let's explore about Soto first.", textSize: 30)
                        .padding()
                        .offset(x:300, y:0).frame(maxWidth: 450)
                    NavigationLink(destination: SotoView()) {
                        Capsule()
                            .fill(Color(red:168/255, green:0/255,blue:0/255))
                            .frame(width: 300,height: 80)
                            .overlay(Text("What is Soto?").foregroundColor(.white).font(.system(size: 35,weight: .bold)))
                            .padding(.leading,40)
                    }.padding(.bottom,30).padding(.top,50)
                    NavigationLink(destination: TypeView()) {
                        Capsule()
                            .fill(Color(red:168/255, green:0/255,blue:0/255))
                            .frame(width: 300,height: 80)
                            .overlay(Text("Type of Soto").foregroundColor(.white).font(.system(size: 35,weight: .bold)))
                            .padding(.leading,40)
                    }
                }
            }
        }
    }
}

struct MyCustomBackButton: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        Button(action: {
            presentationMode.wrappedValue.dismiss() // Dismiss the view when back button is tapped
        }) {
            ZStack {
                Circle()
                    .fill(Color.white)
                    .frame(width: 30, height: 30)
                
                Image(systemName: "arrow.left")
                    .foregroundColor(Color(red:168/255, green:0/255,blue:0/255)) // Use your maroon color here
            }
        }
    }
}
