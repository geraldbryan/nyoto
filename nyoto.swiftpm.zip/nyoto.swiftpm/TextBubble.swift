import SwiftUI

struct CartoonTextBubble: View {
    var text: String
    var textSize: CGFloat
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(text)
                .padding(EdgeInsets(top: 10, leading: 15, bottom: 10, trailing: 15))
                .foregroundColor(.black)
                .font(.system(size: textSize, weight: .semibold))
                .background(
                    RoundedRectangle(cornerRadius: 20)
                        .fill(Color.white)
                        .shadow(color: Color.black.opacity(0.3), radius: 5, x: 0, y: 2)
                )
        }
        .padding(10)
        .background(
            Image("cartoon_background")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .clipped()
        )
    }
}
