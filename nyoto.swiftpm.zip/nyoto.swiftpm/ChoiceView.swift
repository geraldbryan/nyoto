import SwiftUI

struct ChoiceView: View {
    let imageName: String
    let itemName: ContentModel
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    
    var body: some View {
        ZStack{
            Image("type")
            CartoonTextBubble(text: "Hope you enjoy it!", textSize: 30).offset(x:150,y:-250)
            MenuCardView(imageName: imageName, itemName: itemName.sotoType, contentTitle: itemName)
        }.navigationBarBackButtonHidden(true) // Hide the default back button
            .navigationBarItems(leading: MyCustomBackButton())
    }
}

struct MenuCardView: View {
    let imageName: String
    let itemName: String
    let contentTitle: ContentModel
    @State private var currentIndex = 0
    private let contents = ["First Content", "Second Content", "Third Content"]
    
    var body: some View {
        HStack{
            VStack{
                Image(imageName)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 400, height: 400)
                    .cornerRadius(10)
                    .padding(.init(top: -50, leading: 20, bottom: 0, trailing: 0))
                Text(itemName)
                    .font(.system(size: 35,weight: .bold))
                    .foregroundColor(.black)
                    .padding(.init(top: -50, leading: 20, bottom: 20, trailing: 0))
            }
            Rectangle()
                .fill(.black)
                .frame(width: 5, height: 450)
                .padding(.horizontal)
                .cornerRadius(10)
            HStack(alignment:.center){
                Button(action: {
                    self.currentIndex = (self.currentIndex - 1 + self.contents.count) % self.contents.count
                }) {
                    Image(systemName: "arrow.left")
                        .foregroundColor(.black)
                }.padding(.trailing,25)
                
                VStack{
                    Capsule()
                        .fill(Color.maroon)
                        .frame(width: 400,height: 60)
                        .overlay(Text(contentTitle.sectionType[currentIndex]).foregroundColor(.white).font(.system(size: 35,weight: .bold)))
                        .padding(.init(top: 20, leading: 0, bottom: 10, trailing: 25))
                    Text(contentTitle.sectionDesc[currentIndex])
                        .foregroundColor(.black)
                        .frame(width:400)
                        .padding(.trailing,25)
                }
                
                Button(action: {
                    self.currentIndex = (self.currentIndex + 1) % self.contents.count
                }) {
                    Image(systemName: "arrow.right")
                        .foregroundColor(.black)
                }.padding(.trailing,10)
            }
        }.background(.white).offset(y:200)
    }
}
